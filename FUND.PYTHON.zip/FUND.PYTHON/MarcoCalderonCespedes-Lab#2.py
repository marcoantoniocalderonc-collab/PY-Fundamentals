#Programa que contiene un menu, funciones y resuelve varios problemas. No Utilizar Vectores. / / Hecho por: Marco Calderon Cespedes
import os 
import math
#Funcion que solicita al usuario que ingrese los 3 numeros que se van a utilizar en las otras funciones del programa.
def PedirDatos():
    global num1, num2, num3
    num1 = float(input("Ingrese el primer numero: "))
    num2 = float(input("Ingrese el segundo numero: "))
    num3 = float(input("Ingrese el tercer numero: "))
def CalculoSenoCoseno():
    PedirDatos()
    seno = math.sin(num1)
    coseno = math.cos(num1)
    print("El seno de", num1, "es: ", round(seno, 2))
    print("El coseno de", num1, "es: ", round(coseno, 2))
    seno = math.sin(num2)
    coseno = math.cos(num2)
    print("El seno de", num2, "es: ", round(seno, 2))
    print("El coseno de", num2, "es: ", round(coseno, 2))
    seno = math.sin(num3)
    coseno = math.cos(num3)
    print("El seno de", num3, "es: ", round(seno, 2))
    print("El coseno de", num3, "es: ", round(coseno, 2))
#Preguntar con el profesor, fallo en exponente, revisar.
def CalculoEspecial():
    PedirDatos()
    resultado = ((num1 + num2) / num3 )** 2 
    print("El resultado de la formula es (", num1, "+", num2, ")/", num3, "y exponente 2 es: ", round(resultado, 2))

"""Función Suma_Enteros:  debe solicitar y recibir un número entero positivo, digitado por el 
usuario y después debe mostrar en pantalla la suma de todos los enteros desde 1 hasta N 
que sería el digitado por el usuario. La suma de los primeros 
enteros positivos puede ser calculada con la fórmula: S = N * (N + 1) / 2, donde S es la suma de los primeros enteros positivos y N es el número digitado por el usuario."""
def SumaEnteros():
    global num1
    num1 = float(input("Ingrese un numero entero positivo: "))
    if num1 < 0:
        print("El numero debe ser entero positivo.")
    else:
        suma = num1 * (num1 + 1) / 2
        print("La suma de los primeros", num1, "enteros positivos es: ", float(suma))

''' Función Division_Especial:  Dicha función debe solicitar al usuario dos números enteros y 
como resultado debe mostrar lo siguiente:  
 
La división de <n> entre <m> da un cociente <c> y un resto <r> 
 
Donde <n> y <m> son los números introducidos por el usuario, y <c> y <r> son el cociente y 
el resto de la división entera respectivamente.'''
def DivisionEspecial():
    PedirDatos()
    if num2 == 0:
        print("No se puede dividir entre cero.")
    else:
        cociente = num1 // num2
        resto = num1 % num2
        print("La division de", num1, "entre", num2, "da un cociente", cociente, "y un resto", resto)
""" Función Agrupar_Alumnos:  Esta función debe dividir los alumnos en dos grupos A y B de 
acuerdo al sexo y el nombre de cada uno. El grupo A está formado por las mujeres con un 
nombre anterior a la M y los hombres con un nombre posterior a la N y el grupo B por el resto 
de estudiantes. La función debe solicitar al usuario el nombre y sexo del alumno(a), y mostrar 
por pantalla el grupo que le corresponde.SIN UTILIZAR VECTORES."""    
def AgruparAlumnos():
    nombre = input("Ingrese el nombre del alumno(a): ")
    sexo = input("Ingrese el sexo del alumno(a) (M/F): ")
    if (sexo == "F" and nombre[0].upper() < "M") or (sexo == "M" and nombre[0].upper() > "N"):
        print(nombre, "pertenece al grupo A.")
    else:
        print(nombre, "pertenece al grupo B.")
""" Función Pago_Renta: La función debe pedir al usuario cuanto es el total de su renta anual 
percibida y debe mostrar por pantalla el tipo impositivo que le corresponde cancelar.  Al 
final se muestra la tabla con los porcentajes a aplicar según lo apercibido en el año."""
def CalcularPagoRenta():
    renta = float(input("Ingrese el total de su renta anual percibida: "))
    if renta < 10000:
        print("El tipo impositivo que le corresponde cancelar es del 5%.")
    elif renta < 20000:
        print("El tipo impositivo que le corresponde cancelar es del 15%.")
    elif renta < 35000:
        print("El tipo impositivo que le corresponde cancelar es del 20%.")
    elif renta < 60000:
        print("El tipo impositivo que le corresponde cancelar es del 30%.")
    else:
        print("El tipo impositivo que le corresponde cancelar es del 45%.")
    print("Tabla de porcentajes a aplicar según la renta anual percibida:")
    print("Renta anual percibida - - - Tipo impositivo")
    print("Menos de $10,000 - - - 5%")
    print("$10,000 a $19,999 - - - 15%")
    print("$20,000 a $34,999 - - - 20%")
    print("$35,000 a $59,999 - - - 30%")
    print("$60,000 o más - - - 45%")
"""Función Puntos_Canjeables: En una determinada empresa, sus empleados son evaluados 
al final de cada año. Los puntos que pueden obtener en la evaluación comienzan en 0.0 y 
pueden ir aumentando, traduciéndose en mejores beneficios. Los puntos que pueden 
conseguir los empleados pueden ser 0.0, 0.4, 0.6 o más, pero no valores intermedios entre 
las cifras mencionadas.   La función debe solicitar y leer la puntuación que el usuario digite 
y debe indicar el nivel de rendimiento, así como la cantidad de dinero que recibirá el 
trabajador, dicha cantidad será igual a ¢50000 multiplicada por la puntuación del nivel que 
le corresponda.   Al final se le muestra la tabla con el nivel y la puntuación que debe utilizar."""
def PuntosCanjeables():
    puntos = float(input("Ingrese la puntuacion obtenida en la prueba (0.0, 0.4, 0.6 o mas): "))
    if puntos == 0.0:
        print("Nivel de rendimiento: Insuficiente. Cantidad a recibir: ¢0.")
    elif puntos == 0.4:
        print("Nivel de rendimiento: Regular. Cantidad a recibir: ¢20000.")
    elif puntos == 0.6:
        print("Nivel de rendimiento: Bueno. Cantidad a recibir: ¢30000.")
    elif puntos > 0.6:
        print("Nivel de rendimiento: Excelente. Cantidad a recibir: ", int(50000 * puntos), "colones.")
    else:
        print("Puntuacion no valida.")
    print("Tabla de niveles y puntuaciones:")
    print("Puntuacion - - - Nivel de rendimiento")
    print("0.0 - - - Insuficiente")
    print("0.4 - - - Regular")
    print("0.6 - - - Bueno")
    print("Mas de 0.6 - - - Excelente")

def Menu():
    os.system("cls")
    print("1. Cálculo de Seno y Coseno")
    print("2. álculo Especial")
    print("3. Suma de Enteros")
    print("4. División especial")
    print("5. Agrupar Alumnos")
    print("6. Calcular Pago Renta")
    print("7. Puntos Canjeables")
    print("8. Salir")

continuar = True
while continuar:
    Menu()
    opcion = int(input("Ingrese una opcion: "))
   
    match opcion:
        case 1:
            os.system("cls")
            print("Opcion 1: Cálculo de Seno y Coseno")
            CalculoSenoCoseno()
            input("Digite Enter para continuar")
        case 2:
            os.system("cls")
            print("Opcion 2: Cálculo Especial")
            CalculoEspecial()
            input("Digite Enter para continuar")
        case 3:
            os.system("cls")
            print("Opcion 3: Suma de Enteros")
            SumaEnteros()
            input("Digite Enter para continuar")
        case 4:
            os.system("cls")
            print("Opcion 4: División Especial")
            DivisionEspecial()
            input("Digite Enter para continuar")
        case 5:
            os.system("cls")
            print("Opcion 5: Agrupar Alumnos")
            AgruparAlumnos()
            input("Digite Enter para continuar")
        case 6:
            os.system("cls")
            print("Opcion 6: Calcular Pago Renta")
            CalcularPagoRenta()
            input("Digite Enter para continuar")
        case 7:
            os.system("cls")
            print("Opcion 7: Puntos Canjeables")
            PuntosCanjeables()
            input("Digite Enter para continuar")