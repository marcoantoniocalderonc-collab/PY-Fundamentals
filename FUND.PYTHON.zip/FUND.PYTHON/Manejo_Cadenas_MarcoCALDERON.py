#Codigo secuencial que realiza el manejo de cadenas o strings, utilizando el lenguaje de programacion Python
import os
os.system("cls")
cadena1 = "Hola Mundo"
cadena2 = "Este es otro string"
cadena3 = """Esta es una cadena que abarca
varias lineas, utilizando tres comillas"""

texto = " texto con espacios  "
texto1 = "PRUEBA EN MAYUSCULAS"
texto3 = "Mi CaDena DIvErtiDA"
saludo = 'Hola todo bien mis muchachos'

menu = """ *** Menu nuevo en Python ***  \n 1.Cadena en mayusculas \n 2.Cadena en minusculas \n 3.Orden Ascendente \n 4.Orden Descendente \n 5.Salir"""
print(cadena1)
print(cadena2)
print(cadena3)
print(menu)

print("    *** Menú nuevo en Python *** \n      1. Cadena en mayúsculas \n      2. Cadena en minúsculas \n      3. Orden Ascendente \n"
      "      4. Orden Descendente \n      5. Salir")

x = "abcdefghijklmnopqrstuvwxyz"
#imprime la posición 0 + la última posición de cadena1  H!
print(cadena1[0] + cadena1[-1])

#imprime la posición 6 de cadena1 
print(cadena1[6])
#imprime la penúltima -2 y última -1 de la variable saludo  @s
print(saludo[-2] + saludo[-1])
#imprime desde la primera posición, 15 caracteres de la variable saludo   Hola, todo bien
print(saludo[0:15])
#imprime desde la posición 15 en adelante de la variable saludo
print(saludo[15:])
##imprime desde posición 0, 6 caracteres de cadena1 más cadena2 más de la posición 15 en adelante de la variable saludo
print(cadena1[0:6] + cadena2 + saludo[15:])
#imprime la variable x, desde la primera posición 14 caracteres pero de 2 en 2 (cuenta el caracter que imprime)
print(x[0:14:2])
#imprime la variable x, desde la primera posición TODOS caracteres pero de 2 en 2 (cuenta el caracter que imprime)
print(x[::2])
print(x[::5])
print(texto)
print("Longitud de la variable texto:", len(texto))
t1 = texto.strip()
print("Longitud de la variable texto sin espacios:", len(t1))
print(texto)

#La función lower (pasa el texto a minúscula) - Función upper (pasa el texto a mayúscula) - Función capitalize (primer letra en mayúscula)
print("Esto es la variable t1 con capitalize:", t1.capitalize())
print("")
print("Esto es la variable t1 con lower:", t1.lower())
print("")
print("Esto es texto1:", texto1)
print("Esto es la variable texto1 con upper:", texto.upper())


