#Crear un archivo en formato CSV separado por comas, con datos provenientes de una lista
#   sumar los datos numéricos y colocarlos en la última fila del csv.

import os
import csv
import gc  

gc.collect()  #garbage collection
os.system("cls")
#codigo para leer un archivo en formato CSV separado por comas.
nombre_archivo = r"C:\\Users\\marco\\Documents\\FUND.PYTHON\\Nombres.csv"

with open(nombre_archivo, mode='r') as file:
    csv_reader = csv.reader(file, delimiter=',')
    cuenta_lineas = 0
    for row in csv_reader:
        if cuenta_lineas == 0:
            print(f"Los nombres de las columnas son: {', '.join(row)}")
        else:
            print(f"\t{row[0]} trabaja en {row[1]}, mes de cumpleaños: {row[2]}")
        cuenta_lineas += 1
    print(f"El número total de líneas es: {cuenta_lineas}")