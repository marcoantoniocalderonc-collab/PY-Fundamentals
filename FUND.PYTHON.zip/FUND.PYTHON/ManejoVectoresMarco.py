#Codigo que maneja vectores en python
import os
os.system('cls') #Limpia la pantalla en Windows, en otros sistemas operativos puede ser 'clear'

def Recorre_Vector():
    #os.system("cls")
    for i in range(len(edades)):
        print("Posición No.", i ,"del vector:",edades[i])

mi_lista = ['Kenner','Pedro','Laura','Susana']
print(mi_lista[-1]) #Imprime el último elemento de la lista
print(mi_lista[0]) #Imprime el primer elemento de la lista
print(mi_lista[-2]) #Imprime el penúltimo elemento de la lista
print(mi_lista[-3]) #Imprime el antepenúltimo elemento de la lista

edades = [20,41,6,18,84,23,27,14,9]
print(" ")  # recorre e imprime el vector de forma vertical
for edad in edades:
    print(edad, end=' - - - ')
print(" ")  # recorre e imprime el vector de forma vertical
print("Tamaño del vector edades: ", len(edades)) #Imprime el tamaño del vector
print("Tamaño del vector mi_lista: ", len(mi_lista)) #Imprime el tamaño del vector

indice = 0
while indice < len(edades):
    print ("Posición No.",indice,"del vector:",edades[indice])
    indice += 1

print(" ")  
for i in range(len(edades)):
    print ("Posición No.",indice + 1,"del vector:",edades[i])

print(" ") #insertar datos en el vector edades, appennd
edades.append(30) #Agrega el número 30 al final del vector edades
print(edades)

edades.pop(-1) #Elimina el último elemento del vector edades

#agregar datos a los vectores con un for
for i in range(tama):
    print("Ingrese los datos de la persona No.", i + 1)
    nombre = input("Digite el nombre: ")
    id = input("Digite la identificación: ")
    edad_persona = int(input("Digite la edad: "))
    nombres.append(nombre)
    identificacion.append(id)
    edad.append(edad_persona)

input("Digite enter para continuar")
os.system("cls")

#mostrar los dartos de los vectores
print()
print(" *** Datos almacenados de las diferentes personas *** \n")
for i in range(tama):
    print("Persona No.", i + 1)
    print("Nombre:",nombres[i])
    print("Identificación:",identificacion[i])
    print("Edad:",edad[i])
    print()