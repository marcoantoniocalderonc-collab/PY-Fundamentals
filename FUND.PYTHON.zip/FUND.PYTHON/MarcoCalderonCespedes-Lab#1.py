#Programa que contiene un menu, funciones y resuelve varios problemas. / / Hecho por: Marco Calderon Cespedes
import os 
import math
#Funcion que solicita al usuario que ingrese los 4 numeros que se van a utilizar en las otras funciones del programa.
def PedirDatos():
    global num1, num2, num3, num4
    num1 = float(input("Ingrese el primer numero: "))
    num2 = float(input("Ingrese el segundo numero: "))
    num3 = float(input("Ingrese el tercer numero: "))
    num4 = float(input("Ingrese el cuarto numero: "))  
#Funcion que calcula el promedio de num1, num2, num3 y num4 utilizando la funcion PedirDatos.
def Promedio():
   PedirDatos()
   suma = num1 + num2 + num3 + num4
   promedio = suma / 4
   print("El promedio de", num1, ",", num2, ",", num3, "y", num4, "es: ", round(promedio, 2))
#Funcion que calcula el numero mayor de num1, num2, num3 y num4 utilizando la funcion PedirDatos.
def Mayor():
    PedirDatos()
    mayor = max(num1, num2, num3, num4)
    print("El numero mayor es: ", mayor)
#Funcion que calcula el numero menor de num1, num2, num3 y num4 utilizando la funcion PedirDatos.
def Menor():
    PedirDatos()
    menor = min(num1, num2, num3, num4)
    print("El numero menor es: ", menor)
#Funcion de par y impar.
def parImpar():
    PedirDatos()
    if num1 % 2 == 0:
        print(num1, "es un numero par.")    
    else:
        print(num1, "es un numero impar.")
    if num2 % 2 == 0:
        print(num2, "es un numero par.")
    else:
        print(num2, "es un numero impar.")
    if num3 % 2 == 0:
        print(num3, "es un numero par.")
    else:
        print(num3, "es un numero impar.")
    if num4 % 2 == 0:
        print(num4, "es un numero par.")
    else:
        print(num4, "es un numero impar.")
#Revisar o consultar con el profe
def Aumentar():
    PedirDatos()
    suma = num1 + num2 + num3 + num4
    aumento = suma * 0.70
    print("La suma de los numeros es: ", float(suma))
    print("Dicha suma aumentada en un 70% es: ", float(aumento))
    
#Revisar o consultar con el profe
def RaizCuadrada():
    PedirDatos()
    if num1 < 0:
        print("No se puede calcular la raiz cuadrada de un numero negativo.")
    else:
        raiz = math.sqrt(num1)
        print("La raiz cuadrada de", num1, "es: ", round(raiz, 2))
    if num2 < 0:
        print("No se puede calcular la raiz cuadrada de un numero negativo.")
    else:
        raiz = math.sqrt(num2)
        print("La raiz cuadrada de", num2, "es: ", round(raiz, 2))
    if num3 < 0:
        print("No se puede calcular la raiz cuadrada de un numero negativo.")
    else:
        raiz = math.sqrt(num3)
        print("La raiz cuadrada de", num3, "es: ", round(raiz, 2))
    if num4 < 0:
        print("No se puede calcular la raiz cuadrada de un numero negativo.")
    else:
        raiz = math.sqrt(num4)
        print("La raiz cuadrada de", num4, "es: ", round(raiz, 2))

def OrdenarAscendente():
    global num1, num2, num3, num4
    PedirDatos()
    if (num1 > num2):
        num1, num2 = num2, num1
    if (num3 > num4):
        num3, num4 = num4, num3
    if (num2 > num4):
        num2, num4 = num4, num2
    if (num1 > num3):
        num1, num3 = num3, num1
    if (num2 > num3):
        num2, num3 = num3, num2
    if (num1 > num4):
        num1, num4 = num4, num1
    print("Los numeros ordenados de forma ascendente son: ", num1, ",", num2, ",", num3, "y", num4)

def OrdenarDescendente():
    PedirDatos()
    if (num1 < num2):
        num1, num2 = num2, num1
    if (num3 < num4):
        num3, num4 = num4, num3
    if (num2 < num4):
        num2, num4 = num4, num2
    if (num1 < num3):
        num1, num3 = num3, num1
    if (num2 < num3):
        num2, num3 = num3, num2
    if (num1 < num4):
        num1, num4 = num4, num1
    print("Los numeros ordenados de forma descendente son: ", num1, ",", num2, ",", num3, "y", num4)

def PositivoNegativoCero():
    PedirDatos()
    if num1 > 0:
        print(num1, "es un numero positivo.")
    elif num1 < 0:
        print(num1, "es un numero negativo.")
    else:
        print(num1, "es cero.")
    if num2 > 0:
        print(num2, "es un numero positivo.")
    elif num2 < 0:
        print(num2, "es un numero negativo.")
    else:
        print(num2, "es cero.")
    if num3 > 0:
        print(num3, "es un numero positivo.")
    elif num3 < 0:
        print(num3, "es un numero negativo.")
    else:
        print(num3, "es cero.")
    if num4 > 0:
        print(num4, "es un numero positivo.")
    elif num4 < 0:
        print(num4, "es un numero negativo.")
    else:
        print(num4, "es cero.")

def Menu():
    os.system("cls")
    print("- - - MENU DE OPCIONES LABORATIORIO #1 - - -")
    print("1. Ordenar Numeros Ascendentemente.")
    print("2. Ordenar Numeros Descendentemente.")
    print("3. Promedio")
    print("4. Aumentar")
    print("5. Mayor")
    print("6. Menor")
    print("7. Raiz Cuadrada")
    print("8. Positivo - Negativo - Cero")
    print("9. Par - Impar")
    print("10. Salir")

continuar = True
while continuar:
    Menu()
    opcion = int(input("Ingrese una opcion: "))
   
    match opcion:
        case 1:
            os.system("cls")
            print("Opcion 1: Ordenar Numeros Ascendentemente.")
            OrdenarAscendente()
            input("Digite Enter para continuar")
        case 2:
            os.system("cls")
            print("Opcion 2: Ordenar Numeros Descendentemente.")
            OrdenarDescendente()
            input("Digite Enter para continuar")
        case 3:
            os.system("cls")
            print("Opcion 3: Promedio")
            Promedio()
            input("Digite Enter para continuar")
        case 4:
            os.system("cls")
            print("Opcion 4: Aumentar")
            Aumentar()
            input("Digite Enter para continuar")
        case 5:
            os.system("cls")
            print("Opcion 5: Mayor")
            Mayor()
            input("Digite Enter para continuar")
        case 6:
            os.system("cls")
            print("Opcion 6: Menor")
            Menor()
            input("Digite Enter para continuar")
        case 7:
            os.system("cls")
            print("Opcion 7: Raiz Cuadrada")
            RaizCuadrada()
            input("Digite Enter para continuar")
        case 8:
            os.system("cls")
            print("Opcion 8: Positivo - Negativo - Cero")
            PositivoNegativoCero()
            input("Digite Enter para continuar")
        case 9:
            os.system("cls")
            print("Opcion 9: Par - Impar")
            parImpar()
            input("Digite Enter para continuar")
        case 10:
            print("Saliendo del programa")
            continuar = False
        case _:
            print("Opcion no valida, intente de nuevo.")
            input("Digite Enter para continuar")
