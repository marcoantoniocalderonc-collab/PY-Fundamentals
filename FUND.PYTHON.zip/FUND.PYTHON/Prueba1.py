#Este programa maneja codigo secuencial y estructurado, utiliza tres variables y realiza con ellas 
#algunas operaciones basicas y otras.

num1, num2, num3 = 1000, 2000, 3000
suma = num1 + num2 + num3
print("La suma de los numeros es: ", str(suma))
print("La suma de los numeros es: ", suma)
print("")

num1 = float(input("Ingrese el primer numero: "))
num2 = float(input("Ingrese el segundo numero: "))
num3 = float(input("Ingrese el tercer numero: "))

#Instrucciones - código para SUMAR, MULTIPLICAR y DIVIDIR los valores que traen las variables nu1, num2 y num3
suma = num1 + num2 + num3
print("El resultado de sumar", num1, "+", num2, "+", num3, "es: ", round(suma))

multiplicacion = num1 * num2 * num3
print("El resultado de multiplicar", num1, "*", num2, "*", num3, "es: ", round(multiplicacion))

resta = num1 - num2 - num3
print("El resultado de restar", num1, "-", num2, "-", num3, "es: ", round(resta))


if num2 == 0:
    print("No se puede dividir por cero.")
else:
    dividir = num1 / num2 
    print("El resultado de dividir", num1, "/", num2,"es: ", round(dividir, 2))

#calcular el promedio de num1, num2 y num3
promedio = (num1 + num2 + num3) / 3
print("El promedio de", num1, ",", num2, "y", num3, "es: ", round(promedio, 2))

#decir si num1, num2 y num3 es par o impar
if num1 % 2 == 0:
    print(num1, "es un numero par.")    
else:
    print(num1, "es un numero impar.")
if num2 % 2 == 0:
    print(num2, "es un numero par.")
else:
    print(num2, "es un numero impar.")
if num3 % 2 == 0:
    print(num3, "es un numero par.")
else:
    print(num3, "es un numero impar.")

#Calcular si num1, num2 y num3 es negativo o es positivo
if num1 > 0:
    print(num1, "es un numero positivo.")
elif num1 < 0:
    print(num1, "es un numero negativo.")
if num2 > 0:
    print(num2, "es un numero positivo.")
elif num2 < 0:
    print(num2, "es un numero negativo.")
if num3 > 0:
    print(num3, "es un numero positivo.")
elif num3 < 0:
    print(num3, "es un numero negativo.")

