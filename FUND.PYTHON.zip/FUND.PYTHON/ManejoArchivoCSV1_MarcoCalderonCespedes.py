#Crear un archivo en formato CSV separado por comas, con datos provenientes de una lista
#   sumar los datos numéricos y colocarlos en la última fila del csv.

import os
import csv
import gc  

gc.collect()  #garbage collection
os.system("cls")

#definir el nombre del archivo
nombre_archivo = r"C:\\Users\\marco\\Documents\\FUND.PYTHON\\datos.csv"

#crear los datos de ejuemplo
datos = [
    ["Nombre", "Edad",],
    ["Marco", 25],
    ["Marco", 19],
    ["Marco", 45],
    ["Marco", 77],  
]

#sumar la columna edad
total_edades = sum(fila[1] for fila in datos[1:])  #suma de la columna edad, omitiendo la fila de encabezado
print (f"Total de edades: {total_edades}")

#especificar la fila en donde se va a colocar el total
fila_total = len(datos)  #fila total es la siguiente a la última fila de datos

#Calcular el promedio de edades
promedio_edades = total_edades / (len(datos) - 1)  #promedio de edades, dividiendo el total entre el número de filas de datos

#Añadir el total a la última fila de datos
datos.append(['TOTAL',total_edades])
datos.append(['PROMEDIO',promedio_edades])

print(datos)
#Escribir datos en el archivo
with open(nombre_archivo, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(datos) #en una sola linea

#m0strar el contenido del archivo
with open(nombre_archivo, mode='r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
