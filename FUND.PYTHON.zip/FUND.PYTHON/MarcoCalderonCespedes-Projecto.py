# Proyecto 1: Funciones con Cadenas de Texto (Strings), Marco Calderon Cespedes, 2026 - 03 - 14
import os 
import math

"""Realizar un programa que muestre por consola un menú con las siguientes 
opciones. 
 
   MENU DE OPCIONES A REALIZAR  
1. Función Cadena 1 
2. Función Cadena 2 
3. Función Cadena 3 
4. Salir 
   Ingresa la opción:"""

""" Si se digita una opción diferente a las que se tiene en el menú, debe mostrar 
un mensaje que diga:  Opción Inválida, debe hacer una pausa y volver al menú."""

def Menu():
    os.system("cls")
    print("- - - MENU DE OPCIONES A REALIZAR PROYECTO 1 - - -")
    print("1. Función Cadena 1 ")
    print("2. Función Cadena 2 ")
    print("3. Función Cadena 3 ")
    print("4. Salir ")
   
"""❖ Función Cadena 1: 
• Solicitar al usuario que digite una cadena o string. 
• Contar y mostrar el número de letras que tiene dicha cadena 
• Contar y mostrar el número de palabras que contiene 
• Contar y mostrar el número de vocales, consonantes y espacios en 
blanco que contiene dicha cadena 
• Mostrar la cadena en consola invertida palabra a palabra 
• Presentarla en consola invertida letra a letra 
• Realizar una pausa para observar todo lo solicitado. """

def FuncionCadena1():
    cadena = input("Digite una cadena o string: ")
    num_letras = len(cadena.replace(" ", ""))
    num_palabras = len(cadena.split())
    num_vocales = sum(cadena.lower().count(vocal) for vocal in "aeiou")
    num_consonantes = sum(cadena.lower().count(consonante) for consonante in "bcdfghjklmnpqrstvwxyz")
    num_espacios = cadena.count(" ")
    
    print("Número de letras: ", num_letras)
    print("Número de palabras: ", num_palabras)
    print("Número de vocales: ", num_vocales)
    print("Número de consonantes: ", num_consonantes)
    print("Número de espacios en blanco: ", num_espacios)
    
    palabras_invertidas = " ".join(reversed(cadena.split()))
    print("Cadena invertida palabra a palabra: ", palabras_invertidas)
    
    cadena_invertida = cadena[::-1]
    print("Cadena invertida de letra a letra: ", cadena_invertida)

""" Función Cadena 2: 
• Definir una string a con la cadena «Esto es una string» 
• Definir otra string b con la cadena «Y esto también». 
• Comparar las dos strings y decir si son iguales 
• Crear la string «c» con la concatenación de a y b 
• Mostrar la string «c» 
• Crear la string «d» con la concatenacion de a y b otra vez 
• Mostrar la string  «d» 
• Comparar las string c y d y decir si son iguales 
• Indicar (mostrar) cuantos caracteres tiene cada una de las strings 
• Copiar la string a en la string b  
• Utilizar replace, para modificar la string a 
• Presentar en consola el contenido de la string a y de la string b. 
• Realizar una pausa para observar todo lo solicitado """

def FuncionCadena2():
    a = "Esto es una string"
    b = "Y esto también"
    
    print("String a: ", a)
    print("String b: ", b)
    
    if a == b:
        print("Las strings son iguales")
    else:
        print("Las strings son diferentes")
    
    c = a + b
    print("String c (concatenación de a y b): ", c)
    
    d = a + b
    print("String d (concatenación de a y b): ", d)
    
    if c == d:
        print("Las strings c y d son iguales")
    else:
        print("Las strings c y d son diferentes")
    
    print("Número de caracteres en a: ", len(a))
    print("Número de caracteres en b: ", len(b))
    print("Número de caracteres en c: ", len(c))
    print("Número de caracteres en d: ", len(d))
    
    b = a
    print("String b después de copiar a: ", b)
    
    a = a.replace("una", "una nueva")
    print("String a después de modificarla: ", a)
    print("String b después de modificar a: ", b)

""" Función Cadena 3: 
• Definir una string X con la cadena “zbvcjljhgfskiuoytraeio” 
• Definir otra string Y con la cadena “zacate, tomate, pastilla, comida, 
ave, honda, jocote». 
• Ordenar ascendentemente la cadena X y mostrarla. 
• Ordenar descendentemente la cadena X y mostrarla. 
• Ordenar ascendentemente la cadena Y, y mostrarla. 
• Ordenar descendentemente la cadena Y, y mostrarla. 
• Realizar una pausa para observar todo lo solicitado"""

def FuncionCadena3():
    X = "zbvcjljhgfskiuoytraeio"
    Y = "zacate, tomate, pastilla, comida, ave, honda, jocote"
    
    X_ascendente = "".join(sorted(X))
    print("Cadena X ordenada ascendentemente: ", X_ascendente)
    
    X_descendente = "".join(sorted(X, reverse=True))
    print("Cadena X ordenada descendentemente: ", X_descendente)
    
    Y_ascendente = " ".join(sorted(Y.split()))
    print("Cadena Y ordenada ascendentemente: ", Y_ascendente)
    
    Y_descendente = " ".join(sorted(Y.split(), reverse=True))
    print("Cadena Y ordenada descendentemente: ", Y_descendente)

#definicion del menu y la opcion de salir del programa, codigo realizado en otros archivos y modificado.
continuar = True
while continuar:
    Menu()
    opcion = int(input("Ingrese una opcion: "))
   
    match opcion:
        case 1:
            os.system("cls")
            print("Opcion 1: Función Cadena 1")
            FuncionCadena1()
            input("Digite Enter para continuar")
        case 2:
            os.system("cls")
            print("Opcion 2: Función Cadena 2")
            FuncionCadena2()
            input("Digite Enter para continuar")
        case 3:
            os.system("cls")
            print("Opcion 3: Función Cadena 3")
            FuncionCadena3()
            input("Digite Enter para continuar")
        case 4:
            os.system("cls")
            print("Opcion 4: Salir")
            continuar = False
            os.system("cls")
        case _:
            os.system("cls")
            print("Opción Inválida")
            input("Digite Enter para continuar")

print()    
print(Menu)


